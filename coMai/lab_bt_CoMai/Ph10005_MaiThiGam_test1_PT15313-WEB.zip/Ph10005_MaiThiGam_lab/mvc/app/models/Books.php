<?php
namespace App\Models;

class Books extends BaseModel{
    protected $tableName = 'books';


}