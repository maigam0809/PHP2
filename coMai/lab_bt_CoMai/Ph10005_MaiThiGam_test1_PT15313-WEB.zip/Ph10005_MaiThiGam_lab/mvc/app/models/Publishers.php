<?php
namespace App\Models;

class Publishers extends BaseModel{
    protected $tableName = 'publishers';
}



